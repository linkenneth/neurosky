import time
import sys

while True:
    print "HOLA"
    sys.stdout.flush()
    time.sleep(1)
